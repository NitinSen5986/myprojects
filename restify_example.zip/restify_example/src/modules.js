var loginhndler=require('./loginHandler')
var namehndler=require('./NameHandler.js')
modulearr=[loginhndler,namehndler]

module.exports=modulearr