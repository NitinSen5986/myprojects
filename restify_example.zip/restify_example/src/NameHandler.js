module.exports={
	getapilist:function(){
		
		apilist=[
		
		{
			Method:'GET',
			Route:{
				path:'/getname'
			},
			respond:getName
		},
		{
			
			Method:'POST',
			Route:{
				path:'/submitdetails'
			},
			respond:submitDetails
		}
			
		]
		
		return apilist
		
		
		
		
	}
}

function getName(req,resp){
	
	resp.send('name is ')
}

function submitDetails(req,resp){
	resp.send('data saved')
}

