module.exports={
	getapilist:function (){
		
		apilist=[
		{Method:'GET',
			Route:{
				path:'/login/:id'
			
			},
		respond:loginname
		},
		{
			Method:'GET',
			Route:{
				path:'/login/'
			
			},
		respond:login
		}
		
		]
		return apilist
		
	}
}

function loginname(req,resp){
	resp.send('Hello'+req.params.id)
}

function login(req,resp){
	resp.send('Hello')
}