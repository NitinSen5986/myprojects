var restify=require("restify")

var server=restify.createServer()

var modules=require('./modules.js')
server.pre(restify.pre.sanitizePath())
//server.use(restify.bodyParser({}))
//server.use(restify.queryParser())

modules.forEach(function(module){
	apilist=module.getapilist()
	apilist.forEach(function(api){

		switch(api.Method){

			case 'GET':
				  //console.log(typeof(api.respond))
			      server.get(api.Route,api.respond)
			      break;
			case 'POST':
				  server.post(api.Route,api.respond)
				  break;
			default:
			      console.log("undefined")
		}

	})
	
})



server.listen(8004,function(){
	console.log("listening")
})