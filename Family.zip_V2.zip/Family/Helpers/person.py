class Person:
	'''This class is use to store a person in the family. For every person we can create a object of this class'''
	def __init__(self,name,gen):
		self.name=name
		self.gen=gen
		self.partner=None
		self.child={}
		self.mother=None