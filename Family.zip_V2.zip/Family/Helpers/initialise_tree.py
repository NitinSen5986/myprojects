from Helpers.person import Person
from Helpers.family import Family
from Helpers.constants import ROOT_MOTHER,ROOT_PARTNER,FEMALE,MALE
class Intialise_Existing:
	'''This class initialises the tree with given usecase.Iw ill return the object of family class which hold the root of the tree'''
	def __init__(self):
		self.member1=Person(ROOT_MOTHER,FEMALE)
		self.member2=Person(ROOT_PARTNER,MALE)
		self.member1.partner=self.member2
		self.member2.partner=self.member1
		self.first_family=Family(self.member1);
	def get_existing_tree(self):
		return self.first_family.root
