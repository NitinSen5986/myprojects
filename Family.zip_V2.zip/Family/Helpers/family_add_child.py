from Helpers.person import Person
from Helpers.constants import SAMPLE,FEMALE,MALE,SUCCEEDED,FAILED,NOTFOUND
class Add_Child:
	def __init__(self,root):
		self.root=root
	def add_child(self,mname,name,gen,user=True,partner_Person=None):
		temp=self.root
		child=Person(name,gen)
		
		check=self.create_child(temp,mname,child,partner_Person)
		if(check is False and user):
			#print('PERSON_NOT_FOUND')
			return(NOTFOUND)
		elif(check==1 and user):
			#print('CHILD_ADDITION_FAILED')
			return(FAILED)
		elif(user):
			#print('CHILD_ADDITION_SUCCEEDED')
			return(SUCCEEDED)
			
	def create_child(self,temp,mname,child_data,partner_Person=None):

		if(temp.gen==FEMALE):
		
			if(temp.name==mname ):

				child_data.mother=temp
				temp.child[child_data.name]=(child_data)
				
				if(partner_Person is not None):
					
					partner_Person.partner=child_data
					child_data.partner=partner_Person
				return temp
			elif(temp.partner is not None):
				if(temp.partner.name==mname):
					return 1
				elif(len(temp.child)>0):
				
					for i in temp.child.values():
						a=self.create_child(i,mname,child_data,partner_Person)
						if(a):
							return(a)

		else:
			if(temp.name ==mname):
				return 1;
			elif(temp.partner is not None):
				a=self.create_child(temp.partner,mname,child_data,partner_Person)
				if(a):
					return(a)
	
		return False	
