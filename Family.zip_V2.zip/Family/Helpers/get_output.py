from Helpers.constants import ADD_CHILD_ACTION , GET_RELATIONSHIP_ACTION
from Helpers.family_add_child import Add_Child
from Helpers.family_find_relation import Find_Relation
class GetOutput:
	def __init__(self,input_data,first_family):
		self.input_data=input_data
		self.root=first_family
	def print_output(self):

		for inp in self.input_data:
			if(inp[0]==ADD_CHILD_ACTION):
				child=Add_Child(self.root)
				if(len(inp)==4):
					print(child.add_child(inp[1],inp[2],inp[3]))
				else:
					
					temp=inp[1]+' '+inp[2]
					print(child.add_child(temp,inp[3],inp[4]))
				
			elif(inp[0]==GET_RELATIONSHIP_ACTION):
				relation=Find_Relation(self.root)
				if(len(inp)>3):
					temp=inp[1]+' '+inp[2]
					print(relation.find_relation(temp,inp[-1]))
				else:
					print(relation.find_relation(inp[1],inp[-1]))
				

				
