import logging
from logging.handlers import TimedRotatingFileHandler

FORMATTER = logging.Formatter('%(asctime)s:%(levelname)s:%(name)s:%(message)s')
LOG_FILE = "app.log"


def get_file_handler():
    file_handler = TimedRotatingFileHandler(LOG_FILE, when='midnight')
    file_handler.setFormatter(FORMATTER)
    return file_handler


def get_logger(logger_name):
    logger = logging.getLogger(logger_name)
    # setting the logging level to INFO
    logger.setLevel(logging.INFO)
    logger.addHandler(get_file_handler())
    return logger
