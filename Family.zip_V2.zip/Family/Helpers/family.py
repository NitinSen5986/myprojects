from Helpers.person import Person
from Helpers.constants import SAMPLE
from Helpers.family_add_child import Add_Child
class Family :
	'''This class represents athe whole family.It contains various actions which can be performed on family members'''
	def __init__(self,root):
		self.root=root
		#This is the sample relations.It contails all the relations of the family which are currently present.In order to define new relation in family entry should be added here'''

		self.sample=SAMPLE

		add_child=Add_Child(root)

		for data in self.sample:
			for mname,child in data.items():
				for child_name,child_info in child.items():
					if(type(child_info)is list):
						
						n1=Person(child_info[1],child_info[2])
						
						add_child.add_child(mname,child_name,child_info[0],False,n1)
											
					else:
						
						add_child.add_child(mname,child_name,child_info,False,None)
						
	

	