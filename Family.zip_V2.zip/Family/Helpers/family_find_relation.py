from Helpers.constants import SAMPLE,FEMALE,MALE,NOTFOUND,PATERNAL_UNCLE,MATERNAL_UNCLE,PATERNAL_AUNT,MATERNAL_AUNT,SISTER_IN_LAW,BROTHER_IN_LAW,SON,DAUGHTER,SIBLINGS
class Find_Relation:
	def __init__(self,root):
		self.root=root
		self.relations={PATERNAL_UNCLE:self.find_Paternal_Uncle,MATERNAL_UNCLE:self.find_Maternal_Uncle,PATERNAL_AUNT:self.find_Paternal_Aunt
			,MATERNAL_AUNT:self.find_Maternal_Aunt,SISTER_IN_LAW:self.find_Sister_In_Law
			,BROTHER_IN_LAW:self.find_Brother_In_Law,SON:self.find_Son
			,DAUGHTER:self.find_Daughter,SIBLINGS:self.find_Siblings}
	def find_relation(self,name,relation):
		temp=self.root
		member=self.find_relation_rec(temp,name,relation)
		if(member is not None):

			if(relation in self.relations):
				find_person=self.relations[relation]
			else:
				find_person=None
			
			if(find_person is not None):

				persons=find_person(member)
		
				s=''
				if(len(persons)>0):
					for p in persons:
						s=s+p.name+' '
					#print(s)
					s=s[:-1]
					return(s)
				else:
					#print('NONE')
					return('NONE')
			else:
				#print(RELATIONNOTFOUND)
				return(RELATIONNOTFOUND)
		else:	
			#print(NOTFOUND)
			return(NOTFOUND)
	def find_relation_rec(self,temp,name,relation):
		
		
		if(temp.name==name):
			
			return(temp)
		elif(len(temp.child)>0 and temp.partner.name!=name):
			for child in temp.child.values():
				a=self.find_relation_rec(child,name,relation)
				if(a):
					return(a)
		elif(temp.partner is not None):
			a=self.find_relation_rec(temp.partner,name,relation)
			if(a):
				return(a)
	def find_Paternal_Uncle(self,member):
		sib=[]
		s=[]
		if(member.mother is not None):

			father=member.mother.partner
			#print(father.name)
			sib=self.find_Siblings(father)
			#print(sib[0].name)
			for i in sib:
				if(i.gen==MALE):
					s.append(i)
					
		return s

		
	def find_Maternal_Uncle(self,member):
		sib=[]
		s=[]
		if(member.mother is not None):
			father=member.mother
			sib=self.find_Siblings(father)
			for i in sib:
				if(i.gen==MALE):
					s.append(i)
		return s
	def find_Paternal_Aunt(self,member):
		sib=[]
		s=[]
		if(member.mother is not None):
			father=member.mother.partner
			sib=self.find_Siblings(father)
			for i in sib:
				if(i.gen==FEMALE):
					s.append(i)
		return s
	def find_Maternal_Aunt(self,member):
		sib=[]
		s=[]
		if(member.mother is not None):
			father=member.mother
			sib=self.find_Siblings(father)
			for i in sib:
				if(i.gen==FEMALE):
					s.append(i)
		return s
	def find_Sister_In_Law(self,member):
		sib=[]
		s=[]
		if(member.partner):
			sib=self.find_Siblings(member.partner)
			for i in sib:
				if(i.gen==FEMALE):
					s.append(i)
		else:
			sib=self.find_Siblings(member)
			if(len(sib)>0):
				for i in sib:

					if(i.gen==MALE and i.partner is not None):
						s.append(i.partner)

		return s

	def find_Brother_In_Law(self,member):
		sib=[]
		s=[]
		if(member.partner):
			sib=self.find_Siblings(member.partner)
			for i in sib:
				if(i.gen==MALE):
					s.append(i)
		else:
			sib=self.find_Siblings(member)
			if(len(sib)>0):
				for i in sib:

					if(i.gen==FEMALE and i.partner is not None):
						s.append(i.partner)

		return s
	
	def find_Son(self,member):
		s=[]
		childs=[]
		if(len(member.child)>0):
			childs=member.child
		elif(member.partner is not None):
			if(len(member.partner.child)>0):
				childs=member.partner.child
		if(len(childs)>0):
			for i in childs.values():
				if(i.gen==MALE):
					s.append(i)

		return s

	def find_Daughter(self,member):
		s=[]
		childs=[]
		if(len(member.child)>0):
			childs=member.child
		elif(member.partner is not None):
			if(len(member.partner.child)>0):
				childs=member.partner.child
		if(len(childs)>0):
			for i in childs.values():
				if(i.gen==FEMALE):
					s.append(i)

		return s
	def find_Siblings(self,member):
		s=[]
		if(member.mother is not None):

			childs=member.mother.child
			if(len(childs)>1):
				for i in childs.values():
					if(i.name!=member.name):
						s.append(i)
		return s