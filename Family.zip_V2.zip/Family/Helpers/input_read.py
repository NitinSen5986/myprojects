class InputRead:
	'''This class is used to read input from text file and then provide a list of required actions and data'''
	def __init__(self, filename):
		self.filename=filename
    
	def parse_input(self):
		input_data=[]
		try:

			with open(self.filename) as f:
				commands=f.readlines()
				
		except FileNotFoundError:
			raise
		
		for i in commands:
			a=i.split()
			input_data.append(a)

			
		return input_data


       	
   	

   