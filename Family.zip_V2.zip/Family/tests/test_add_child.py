import unittest
from Helpers.initialise_tree import Intialise_Existing
from Helpers.family_add_child import Add_Child

class TestAddChild(unittest.TestCase):
	existing_family=Intialise_Existing()
	root=existing_family.get_existing_tree()
	expected_output1='CHILD_ADDITION_SUCCEEDED'
	expected_output2='PERSON_NOT_FOUND'
	expected_output3='CHILD_ADDITION_FAILED'
	def test_add_child(self):
		child=Add_Child(self.root)
		output1=child.add_child('Chitra','Aria','Female')
		output2=child.add_child('Pjali','Srutak','Male')
		output3=child.add_child('Asva','Vani','Female')
		self.assertEqual(output1,self.expected_output1)
		self.assertEqual(output2,self.expected_output2)
		self.assertEqual(output3,self.expected_output3)

if __name__ == '__main__':
    unittest.main()


