import unittest
from Helpers.initialise_tree import Intialise_Existing
from Helpers.family_find_relation import Find_Relation

class TestAddChild(unittest.TestCase):
	existing_family=Intialise_Existing()
	root=existing_family.get_existing_tree()
	expected_output1='NONE'
	expected_output2='Satya'
	def test_add_child(self):
		relation=Find_Relation(self.root)
		output1=relation.find_relation('Vasa','Siblings')
		output2=relation.find_relation('Queen Anga','Daughter')
		self.assertEqual(output1,self.expected_output1)
		self.assertEqual(output2,self.expected_output2 )
		

if __name__ == '__main__':
    unittest.main()


