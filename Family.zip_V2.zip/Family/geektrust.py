import sys
from Helpers.input_read import InputRead
from Helpers.get_output import GetOutput
from Helpers.initialise_tree import Intialise_Existing
from Helpers.log_helper import get_logger
logger = get_logger(__name__) 
def main():
	''' This is the main function which will call helper classes to perform actions'''
	input_file = sys.argv[1]
	#Initializing tree with the given use case
	logger.info('fetching input')
	existing_family=Intialise_Existing()
	first_family=existing_family.get_existing_tree()
	#Parsing the input file
	input1=InputRead(input_file)
	input_data=input1.parse_input()
	#Printing output
	logger.info('printing output')
	output1=GetOutput(input_data,first_family)
	output1.print_output()
    
if __name__ == "__main__":
    main()